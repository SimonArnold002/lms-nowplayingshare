# NowPlayingShare — LMS Plugin

## Project Overview
A plugin for Lyrion Music Server (LMS) that generates shareable "Now Playing" card images (1200×630px) from the currently playing track. Built for LMS v9.1.1, tested with Material Skin v6.3.2.

## Server Details
- **LMS Server**: 192.168.1.234:9000
- **OS**: DietPi (Debian-based)
- **Service**: `lyrionmusicserver`
- **Plugin location (local dev)**: `/var/lib/squeezeboxserver/Plugins/NowPlayingShare/`
- **Plugin location (repo install)**: `/var/lib/squeezeboxserver/cache/InstalledPlugins/Plugins/NowPlayingShare/`
- **Log**: `/var/log/squeezeboxserver/server.log`
- **Material Skin (dev build)**: `/usr/share/squeezeboxserver/Plugins/MaterialSkin/`

## Player IDs
- Sonos Beam: `aa:aa:60:90:9c:b0`
- Lounge: `bb:bb:93:32:0d:53`
- DMP-A8: `80:0a:80:5e:2b:7b`
- Kitchen: `cc:cc:de:7f:90:38`
- Sonos Arc: `aa:aa:b8:05:b6:35`
- Dining Room: `50:41:1c:72:4a:c8`

## Install Commands
```bash
# Full reinstall (required when Plugin.pm or install.xml changes)
sudo rm -rf /var/lib/squeezeboxserver/Plugins/NowPlayingShare
sudo unzip NowPlayingShare-plugin.zip -d /var/lib/squeezeboxserver/Plugins/
sudo chown -R squeezeboxserver:nogroup /var/lib/squeezeboxserver/Plugins/NowPlayingShare
sudo systemctl restart lyrionmusicserver

# HTML-only update (no restart needed)
sudo cp index.html /var/lib/squeezeboxserver/Plugins/NowPlayingShare/HTML/EN/plugins/NowPlayingShare/index.html
sudo chown squeezeboxserver:nogroup /var/lib/squeezeboxserver/Plugins/NowPlayingShare/HTML/EN/plugins/NowPlayingShare/index.html
```

## File Structure
```
NowPlayingShare/
├── Plugin.pm                          # Main Perl plugin file
├── install.xml                        # Plugin metadata
├── strings.txt                        # LMS string translations
├── README.md                          # User documentation
├── CHANGELOG.md                       # Version history
├── public.xml                         # Legacy (not used for repo)
├── CLAUDE.md                          # This file
└── HTML/EN/plugins/NowPlayingShare/
    ├── index.html                     # Main plugin UI (single file app)
    └── html/images/
        ├── NowPlayingShareIcon.svg    # Plugin icon — white fill, 512x512
        └── NowPlayingShareIcon_svg.png # Same SVG content renamed (LMS convention)
```

## GitHub Repository
- **URL**: https://github.com/SimonArnold002/lms-nowplayingshare
- **Creator**: CrystalGipsy
- **repo.xml URL**: https://raw.githubusercontent.com/SimonArnold002/lms-nowplayingshare/main/repo.xml
- **ZIP URL**: https://raw.githubusercontent.com/SimonArnold002/lms-nowplayingshare/main/NowPlayingShare-plugin.zip

### Adding to LMS Plugin Manager
In LMS → Settings → Plugins → Additional Repositories add:
```
https://raw.githubusercontent.com/SimonArnold002/lms-nowplayingshare/main/repo.xml
```
**Must use `raw.githubusercontent.com` — NOT `github.com/.../raw/...`**

### Publishing Updates to GitHub
1. Bump version in `install.xml` and `index.html`
2. Build zip locally
3. Calculate SHA BEFORE uploading: `sha1sum NowPlayingShare-plugin.zip`
4. Upload zip to GitHub replacing existing file
5. Update `repo.xml` with new version number and SHA
6. LMS detects update automatically and notifies users

### repo.xml format
```xml
<extensions>
  <details>
    <title lang="EN">NowPlayingShare for Lyrion Music Server</title>
  </details>
  <plugins>
    <plugin name="NowPlayingShare" version="X.X.X" minTarget="9.0.0" maxTarget="*">
      <title lang="EN">Now Playing Share</title>
      <desc lang="EN">Generate a shareable card image from your currently playing track.</desc>
      <url>https://raw.githubusercontent.com/SimonArnold002/lms-nowplayingshare/main/NowPlayingShare-plugin.zip</url>
      <creator>CrystalGipsy</creator>
      <email></email>
      <sha>LOWERCASE_SHA1_HERE</sha>
    </plugin>
  </plugins>
</extensions>
```

## Key Technical Decisions

### Plugin Registration
- `addPageLinks("plugins")` and `addPageLinks("icons")` in both `initPlugin` and `webPages`
- Key: `'PLUGIN_NOW_PLAYING_SHARE'`
- Icon path: `plugins/NowPlayingShare/html/images/NowPlayingShareIcon_svg.png`
- Handler also registered for `NowPlayingShareIcon_svg_50x50.png` (Material Skin plugins page)
- NO Jive node registration

### Icon System
- Both `NowPlayingShareIcon.svg` and `NowPlayingShareIcon_svg.png` contain identical SVG content
- `_svg.png` is just the SVG renamed — this is the LMS convention (same as BBCSounds etc)
- SVG must have white fills (`fill="#ffffff"`) to display on dark backgrounds
- Material Skin strips `_svg.png` suffix and serves via `/material/svg/` handler

### Canvas Renderer
- Pure canvas 2D — no external dependencies
- Card: W=1200, H=630, ART_W=600, PAD=50
- Always uses `midnight` theme: bg `#1a1a1a`, accent `#c9a84c`
- **Square corners** — no clipping, solid dark background fill
- No transparent pixels — safe to paste anywhere without white corner issues
- Preview in UI uses CSS `border-radius` for rounded appearance only
- Full-card blurred background via multi-pass scale blur (mobile compatible)

### Multi-pass Blur (mobile compatible)
`ctx.filter: blur()` not supported on mobile. Use progressive scale down/up:
```javascript
var sizes = [2, 8, 20, 60, 160];
// Draw at each size progressively
```

### Text Layout — Standard tracks
- NOW PLAYING: 20px, 500 weight, white 60% opacity, letter-spacing 0.15em
- Title: 32px default, 700 weight, scales to 20px min, max 2 lines, gap 32px after
- `by` Artist: 26px, scales to 14px
- `from` Album: 22px, wraps to max 2 lines, scales to 12px min
- `subtitle` Grouping: same size as album, only shown if present
- `disc` Disc subtitle: same size as album, only shown if present
- Disc number (e.g. Disc 1 of 2): NOT shown
- All lines use `fontSize + LINE_GAP (18px)` spacing for consistency

### Text Layout — Classical tracks (isClassical = true from LMS)
- NOW PLAYING
- Track title
- `performed by` Artist (trackartist/albumartist fallback)
- `composed by` Composer
- `work` Work/Grouping (· performance if present)
- `from` Album (Year)

### Classical Detection
- Uses `isClassical` field returned directly by LMS in status response
- LMS sets this based on "My work and composer album genres" setting in My Music
- Tag string includes this field via `AABEGIKNPSTV` tag group
- Do NOT try to detect classical ourselves — trust LMS

### Service Logos
- All from Material Skin: `/material/html/images/SERVICE.svg`
- All white-tinted via `source-atop` compositing, 70% opacity
- Detection from `extid` or `url` field:
  - qobuz, bbcsounds (bbc/bbcsounds), spotify, tidal, deezer
  - bandcamp OR bcbits (Bandcamp streams from bcbits.com)
  - radioparadise/radio-paradise, soundcloud, iheartradio
  - tunein, mixcloud, napster, youtube

### Lyrion Logo
- Fetched from `/material/html/images/lyrion-logo.svg`
- White tinted via `source-atop`, 70% opacity
- Top-right of card, service icon to its left

### LMS Tags
```
tags:cdegilopqrstuyAABEGIKNPSTVbhz124
```
Full Material Skin tag string — includes isClassical, work, composer, grouping, discsubtitle, disc, disccount, performance

### Player Detection
- sessionStorage per-tab isolation
- Auto-detects active player on load
- Artist: `loop.artist || loop.trackartist || loop.albumartist`
- Year: only shown if non-zero

### Artwork
- Cache-busting timestamp on artwork URL
- `cache: 'no-store'` on fetch

## LMS JSON-RPC Examples
```bash
# Get player list
curl -s "http://192.168.1.234:9000/jsonrpc.js" \
  -d '{"id":1,"method":"slim.request","params":["",["players","0","10"]]}' \
  -H "Content-Type: application/json" | python3 -m json.tool

# Check what's playing with all tags
curl -s "http://192.168.1.234:9000/jsonrpc.js" \
  -d '{"id":1,"method":"slim.request","params":["PLAYER_ID",["status","-","1","tags:cdegilopqrstuyAABEGIKNPSTVbhz124"]]}' \
  -H "Content-Type: application/json" | python3 -m json.tool | grep -i "composer\|work\|grouping\|isClassical\|url\|extid"

# Check plugin loaded
grep -i "nowplaying" /var/log/squeezeboxserver/server.log | tail -10
```

## Known Issues / Notes
- Icon display in LMS plugins page depends on Material Skin's `/material/plugins/NowPlayingShare/html/images/NowPlayingShareIcon_svg_50x50.png` — may show incorrectly for non-official repo plugins
- Clipboard API requires HTTPS — not available on http://192.168.1.234:9000
- Bandcamp streams from `bcbits.com` not `bandcamp.com` — both detected
- Material Skin dev build is at `/usr/share/squeezeboxserver/Plugins/MaterialSkin/` not the usual cache path
- `defaultState>enabled</defaultState>` in install.xml auto-enables plugin on install
