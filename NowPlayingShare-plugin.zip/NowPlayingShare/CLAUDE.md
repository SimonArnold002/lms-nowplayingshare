# NowPlayingShare — LMS Plugin

## Project Overview
A plugin for Lyrion Music Server (LMS) that generates shareable "Now Playing" card images (1200×630px) from the currently playing track. Built for LMS v9.1.1, tested with Material Skin v6.3.2.

## Server Details
- **LMS Server**: 192.168.1.234:9000
- **OS**: DietPi (Debian-based)
- **Service**: `lyrionmusicserver`
- **Plugin location**: `/var/lib/squeezeboxserver/Plugins/NowPlayingShare/`
- **Log**: `/var/log/squeezeboxserver/server.log`

## Install Commands
```bash
# Full reinstall (required when Plugin.pm or install.xml changes)
sudo rm -rf /var/lib/squeezeboxserver/Plugins/NowPlayingShare
sudo unzip NowPlayingShare-plugin.zip -d /var/lib/squeezeboxserver/Plugins/
sudo chown -R squeezeboxserver:nogroup /var/lib/squeezeboxserver/Plugins/NowPlayingShare
sudo systemctl restart lyrionmusicserver

# HTML-only update (no restart needed)
sudo cp index.html /var/lib/squeezeboxserver/Plugins/NowPlayingShare/HTML/EN/plugins/NowPlayingShare/index.html
sudo chown squeezeboxserver:nogroup /var/lib/squeezeboxserver/Plugins/NowPlayingShare/HTML/EN/plugins/NowPlayingShare/index.html
```

## File Structure
```
NowPlayingShare/
├── Plugin.pm                          # Main Perl plugin file
├── install.xml                        # Plugin metadata (UUID, version, icon path)
├── strings.txt                        # LMS string translations
├── README.md                          # User documentation
├── CHANGELOG.md                       # Version history
├── public.xml                         # GitHub repository definition
├── CLAUDE.md                          # This file
└── HTML/EN/plugins/NowPlayingShare/
    ├── index.html                     # Main plugin UI (single file app)
    └── html/images/
        ├── NowPlayingShareIcon.svg    # Plugin icon (user's custom version — DO NOT OVERWRITE)
        └── NowPlayingShareIcon_svg.png # Plugin icon PNG (required by Material Skin — DO NOT OVERWRITE)
```

## Key Technical Decisions

### Plugin Registration
- Plugin is locally installed in `/var/lib/squeezeboxserver/Plugins/` (NOT InstalledPlugins cache)
- Registers via `addPageLinks("plugins")` and `addPageLinks("icons")` in `initPlugin` and `webPages`
- Icon key: `'PLUGIN_NOW_PLAYING_SHARE'`
- Icon path uses `_svg.png` suffix: `plugins/NowPlayingShare/html/images/NowPlayingShareIcon_svg.png`
- Material Skin strips `_svg.png` and prepends `/material/svg/` to get the SVG
- NO Jive node registration (removed — caused duplicate entries without icons)

### Icon System
- Material Skin fetches icons via `/material/svg/plugins/NAME/html/images/NAME.svg`
- Both `NowPlayingShareIcon.svg` and `NowPlayingShareIcon_svg.png` must exist in `html/images/`
- The icons are user's custom design — DO NOT overwrite during reinstall

### Canvas Renderer
- Pure canvas 2D renderer — no html2canvas, no external dependencies
- Card dimensions: W=1200, H=630, ART_W=600, PAD=50, R=16, BAR_H=0 (bar removed)
- Always uses `midnight` theme: bg `#1a1a1a`, accent `#c9a84c`
- Full-card blurred artwork background (multi-pass scale blur for mobile compatibility)
- `ctx.filter` NOT supported on mobile — always use multi-pass scale blur
- Clean artwork left half, text right half, vertically centred
- Composited onto solid `#1a1a1a` background before export (fixes white corners when pasting)

### Multi-pass Blur (mobile compatible)
```javascript
var sizes = [2, 8, 20, 60, 160];
// Draw artImg through each size progressively — creates blur without ctx.filter
```

### Corner Fix
Card is composited onto a solid dark background using the same rounded clip path before
being placed in the img tag. This ensures no transparent pixels = no white corners when
right-click copied or pasted into apps like Discord.

### Text Sizing
- NOW PLAYING: 20px, 500 weight, white 60% opacity
- Title: 32px default, 700 weight, scales down to 20px min, max 2 lines
- Artist: 28px default, 400 weight, scales to 14px, with "by" prefix (smaller/lighter)
- Album: 24px default, 400 weight, scales to 14px, with "from" prefix (smaller/lighter)
- Year shown only if non-zero

### Logos (top right of card)
- **Lyrion logo**: fetched from `/material/html/images/lyrion-logo.svg`, white tinted via source-atop, 70% opacity
- **Service icon**: fetched from `/material/html/images/SERVICE.svg`, white tinted, 70% opacity
- Both sit in a row top-right: [service icon] [lyrion wordmark]
- Height: 26px each, gap: 12px between them

### Service Detection (extid/url field)
```javascript
qobuz:         extid contains 'qobuz'
bbcsounds:     extid contains 'bbc' or 'bbcsounds'
spotify:       extid contains 'spotify'
tidal:         extid contains 'tidal'
deezer:        extid contains 'deezer'
bandcamp:      extid contains 'bandcamp' OR 'bcbits' (Bandcamp streams from bcbits.com)
radioparadise: extid contains 'radioparadise' or 'radio-paradise'
soundcloud:    extid contains 'soundcloud'
```

### Artwork Caching
- Cache-busting timestamp added to artwork URLs on every fetch
- `cache: 'no-store'` on fetch requests to prevent stale artwork

### Player Detection
- Uses `sessionStorage` for per-tab player isolation
- Auto-detects active player on load

## GitHub Repository
- **URL**: https://github.com/SimonArnold002/lms-nowplayingshare
- **Creator**: CrystalGipsy
- **Repository XML**: https://SimonArnold002.github.io/lms-nowplayingshare/public.xml

## Material Skin Integration
- Appears in Material Skin **Extras** menu via `addPageLinks("plugins")`
- Icon shown in Extras menu via `addPageLinks("icons")` with `_svg.png` path
- Tested with Material Skin v6.3.2

## Known Issues / Notes
- Custom icon files must be backed up before reinstalling — they are user-created
- Mobile blur is approximate — `ctx.filter` not supported on mobile browsers
- Plugin must be in `Plugins/` directory (not `InstalledPlugins/`) as it's locally installed
- Clipboard API requires HTTPS — not available on http://192.168.1.234:9000
- Bandcamp streams from `bcbits.com` not `bandcamp.com` — both detected

## LMS JSON-RPC Examples
```bash
# Get player list
curl -s "http://192.168.1.234:9000/jsonrpc.js" \
  -d '{"id":1,"method":"slim.request","params":["",["players","0","10"]]}' \
  -H "Content-Type: application/json" | python3 -m json.tool

# Get extras loop (check icon registration)
curl -s "http://192.168.1.234:9000/jsonrpc.js" \
  -d '{"id":1,"method":"slim.request","params":["PLAYER_ID",["material-skin","extras","0","25000"]]}' \
  -H "Content-Type: application/json" | python3 -m json.tool

# Check what a player is playing (check extid/url for service detection)
curl -s "http://192.168.1.234:9000/jsonrpc.js" \
  -d '{"id":1,"method":"slim.request","params":["PLAYER_ID",["status","-","1","tags:u"]]}' \
  -H "Content-Type: application/json" | python3 -m json.tool | grep -i "url\|extid"

# Check plugin loaded
grep -i "nowplaying" /var/log/squeezeboxserver/server.log | tail -10
```
