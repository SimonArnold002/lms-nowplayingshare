# NowPlayingShare — LMS Plugin

A plugin for [Lyrion Music Server](https://lyrion.org) that generates a shareable **Now Playing** card image from your currently playing track.

## Features

- Beautiful 1200×630 card with blurred artwork background
- Clean album art in the left half, track info on the right
- Three themes: **Dark**, **Olive**, **Midnight**
- Auto-scaling text for long titles and artist names
- Auto-refresh — detects track changes and regenerates the card
- Multi-player support with player picker
- Save as PNG or right-click to copy

## Installation

### Via LMS Plugin Manager (recommended)
Add this URL to **Settings → Plugins → Additional Repositories**:
```
https://SimonArnold002.github.io/lms-nowplayingshare/public.xml
```
Then search for "Now Playing Share" and install.

### Manual installation
Download the zip from [Releases](https://github.com/SimonArnold002/lms-nowplayingshare/releases) and extract to your LMS Plugins folder.

## Usage

Open from the **Apps/Extras** menu in Material Skin, or navigate directly to:
```
http://YOUR_LMS_IP:9000/plugins/NowPlayingShare/index.html
```

## Requirements

- Lyrion Music Server 9.0.0 or later
- Material Skin recommended

## License

MIT
